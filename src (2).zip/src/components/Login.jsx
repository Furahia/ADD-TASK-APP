import React from 'react'
import { Link } from "react-router-dom";
function Login() {
  return (
    <div className='container'>

      <ul className='links'>
      <li><Link to={"/comments"}>Comments</Link></li>
        <li><Link to={"/questions"}>Questions</Link></li>
        <li><Link to={"/profile"}>Profile</Link></li>
       </ul>
      
        

        <form action="" className='login'>
            
            <label for="">Enter user name</label>
            <input type="text" name="username"/>
            <br/>
            <label for="">Enter password</label>
            <input type="text" name="password"/>
            <br/>
            <button type="submit" class="btn">LOGIN</button>
        </form>

    </div>
    
  )
}

export default Login