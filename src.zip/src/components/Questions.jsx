import React from 'react'

function Questions() {
  return (
    <div></div>
  )
}

export default Questions