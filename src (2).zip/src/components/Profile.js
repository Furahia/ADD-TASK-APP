import React from 'react'

function Profile() {
  return (
    <div>
        
        <div className='pp'>
        <h3>USER</h3>
        <h4>Your question</h4>
      <input type="text" name="question"/>
      <h4> Your Answers </h4>
      <input type="text" name="answer"/>
      <input type="text" name="answer"/>
      <input type="text" name="answer"/>

        </div>

    </div>
  )
}

export default Profile