import React from 'react'

function Register() {
  return (
    <div className='container'>
       <form action="" className='register'>
            
            <label for="">Name:</label>
            <br/>
            <input type="text" name="name"/>
            <br/>
            <label for="">Your user name:</label>
            <br/>
            <input type="text" name="user name"/>
            <br/>
            <label for="">Your email:</label>
            <br/>
            <input type="text" name="email"/>
            <br/>
            <label for="">Enter password:</label>
            <br/>
            <input type="text" name="password"/>
            <br/>
            <label for="">confirm password:</label>
            <br/>
            <input type="text" name="password"/>
            <br/>
            <h4>forgot password?</h4>
            

            <button type="submit" class="btn">Submit</button>
        </form>
    </div>
  )
}

export default Register