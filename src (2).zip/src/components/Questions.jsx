 import React from 'react'

 function Questions() {
   return (
    <div className='Questions'>
      <div> 
        <h4>Ask a question</h4>
      <input type="text" name="question"/>
      <h4>Answers </h4>
      <input type="text" name="answer"/>
      <input type="text" name="answer"/>
      <input type="text" name="answer"/>
       <div/>
       <button type="submit" class="btn">Delete</button>
        </div>

        <div className='QSTN'> 
        <h4>Ask a question</h4>
      <input type="text" name="question"/>
      <h4>Answers </h4>
      <input type="text" name="answer"/>
      <input type="text" name="answer"/>
      <input type="text" name="answer"/>
       <div/>
       <button type="submit" class="btn">Delete</button>
        </div>

    </div>

    
    
   )
 }

 export default Questions