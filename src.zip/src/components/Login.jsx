import React from 'react'

function Login() {
  return (
    <div>
        
        <form action="" className='login'>
            
            <label for="">Enter user name</label>
            <input type="text" name="username"/>
            <br/>
            <label for="">Enter password</label>
            <input type="text" name="password"/>
            <br/>
            <button type="submit" class="btn">Login</button>
        </form>

    </div>
    
  )
}

export default Login