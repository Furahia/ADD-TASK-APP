export const admins = [
    {
        username: "brendah",
        password: "123"
    },
    {
        username: "bones",
        password: "abc"
    },
    {
        username: "njambi",
        password: "xyz"
    }
]
