import './App.css';
import { Routes, Route } from 'react-router-dom';
import Navigation from './components/Navigation';
import Login from './components/Login';
import Register from './components/Register';
import Questions from './components/Questions';
import Comments from './components/Comments';
import Profile from './components/Profile';
function App() {
  return (
    <div>
      <Navigation />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/questions" element={<Questions/>} />
        <Route path="/comments" element={<Comments/>} />
        <Route path="/profile" element={<Profile/>} />
      </Routes>
    </div>
  )
  
}

export default App;
