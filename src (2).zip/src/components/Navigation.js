import { Link } from "react-router-dom";
import logo from "../assets/logo.png"

function Navigation() {
  return (
    <nav>
      <div className='logo'>
        <img src={logo} alt="" />
      </div>

      <ul className='links'>
        <li><Link to={"/login"}>Login</Link></li>
        <li><Link to={"/register"}>Register</Link></li>
      </ul>
    </nav>
  );
}

export default Navigation;