import React from 'react'

function Comments() {
  return (
    <div className='comment'>
      
       <h4>QUESTION & ITS COMMENTS</h4>
        <h3> QUESTION</h3>
      <input type="text" name="question"/>
      <h3>Ans </h3>
      <input type="text" name="answer"/>
      <input type="text" name="answer"/>
      <input type="text" name="answer"/>

      <h3>Comments </h3>
      <input type="text" name="comment"/>
      <input type="text" name="comment"/>
      <input type="text" name="comment"/>
       <div/>
      
    </div>
  )
}

export default Comments